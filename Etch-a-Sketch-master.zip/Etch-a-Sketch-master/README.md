# Etch-a-Sketch
Odin Project: Etch-a-sketch project

Generates an HTML page with a default 16x16 colored grid;
Features:
  1. Mouse over event will change the color of each square div
  2. Button to reset all squres to its default color
  3. Option to change the canvas's grid size (min: 1x1, max: 100x100)
